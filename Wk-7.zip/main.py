#WORKING WITH FOR LOOPS

#ex. 1

shoping_list = ["berries", "milk", "apple", "juice", "juice"]

for i in shoping_list:
  print(f"I need to buy {i}")

#--------------------------------------
#ex. 2
for num in range(5):
  print(num)
#ex. 3
for num in range(5):
  print("I love it here")


#--------------------------------------
traits = ["talented", "smart", "kind"]

for t in traits:
  print(f"I am {t}")

#--------------------------------------
for t in shoping_list:
  print(t)
  if t == "apple":
    print("I love apples")